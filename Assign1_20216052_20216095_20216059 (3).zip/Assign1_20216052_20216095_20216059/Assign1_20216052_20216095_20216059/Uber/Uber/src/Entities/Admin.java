package Entities;

public class Admin extends User {
    public Admin(String id, String name, String password) {
        super("admin155", "admin", "admin123", "Admin"); 
    }

    
}
