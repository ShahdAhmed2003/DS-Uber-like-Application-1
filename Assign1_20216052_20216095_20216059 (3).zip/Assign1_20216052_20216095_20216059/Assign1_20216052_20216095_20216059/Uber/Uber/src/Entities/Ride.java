package Entities;

import java.util.*;

public class Ride {
    public int rideId;
    public Customer customer;
    public Driver driver;
    public String pickupLocation;
    public String destination;
    public String status; // "Pending", "Accepted", "Ongoing", "Completed"
    public double price;
    public Driver CurrentDriver;
    public Customer CurrentCustomer;
    public List<Driver> RequestedDrivers = new ArrayList<>();
    public Map<String, Double> driverOffers = new HashMap<>();
    public boolean rated = false;
    public Date requestedTime;

    public Ride(int rideId, Customer customer, String pickupLocation, String destination,String status) {
        this.rideId = rideId;
        this.customer = customer;
        this.pickupLocation = pickupLocation;
        this.destination = destination;
        this.status = "Pending";
        this.requestedTime=new Date();
    }

    public void assignDriver(Driver driver, double price) {
        this.driver = driver;
        driverOffers.put(driver.name, price);
    }

    public double getDriverOffer(String driverName) {
        return driverOffers.getOrDefault(driverName, -1.0);
    }
}