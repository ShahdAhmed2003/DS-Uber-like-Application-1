package Entities;

public class Customer extends User {
    public boolean isAvailable = true; 
    public Customer(String id, String name, String password,boolean isAvailable) {
        super(id, name, password, "Customer");
        this.isAvailable=isAvailable; // Pass "Customer" as the type
    }
     // Default to available
}
