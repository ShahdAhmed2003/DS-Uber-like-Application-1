package Entities;

import java.util.ArrayList;
import java.util.List;

public class Driver extends User {
    public boolean isAvailable = true; // Default to available
    public double Rating = 0;
    public int ratingCount = 0;
    public boolean inRide = false;
    public boolean recievedtheride = false;

    // List to store received ride request IDs
    public List<Integer> receivedRequestRides = new ArrayList<>();

    // Constructor with all parameters
    public Driver(String id, String name, String password, boolean isAvailable, double Rating, int ratingCount) {
        super(id, name, password, "Driver"); // Pass "Driver" as the type
        this.isAvailable = isAvailable;
        this.Rating = Rating;
        this.ratingCount = ratingCount;
    }

    // Default constructor (if needed)
    public Driver(String id, String name, String password) {
        super(id, name, password, "Driver");
    }

    // Method to add a ride request ID
    public void addReceivedRide(int rideId) {
        receivedRequestRides.add(rideId);
    }

    // Method to clear received ride requests
    public void clearReceivedRides() {
        receivedRequestRides.clear();
    }
}
