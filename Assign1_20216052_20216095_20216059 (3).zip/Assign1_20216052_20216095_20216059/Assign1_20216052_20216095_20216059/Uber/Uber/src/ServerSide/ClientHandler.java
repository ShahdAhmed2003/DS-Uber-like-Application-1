package ServerSide;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import Entities.*;
import Features.UserService;

public class ClientHandler implements Runnable {
    public static ArrayList<ClientHandler> drivers = new ArrayList<>();
    public static ArrayList<ClientHandler> customers = new ArrayList<>();
    private Socket socket;
    private BufferedReader bufferedreader;
    private BufferedWriter bufferedwriter;
    private User user;
    private String c_name;


    public ClientHandler(Socket socket) throws IOException {
        this.socket = socket;
        this.bufferedwriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        this.bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

    }

    @Override
    public void run() {
        while (true) {

            try {

                bufferedwriter.write("Do you want to Register or Login? (Type 'register' or 'login' or 'admin')");
                bufferedwriter.newLine();
                bufferedwriter.flush();
                String action = bufferedreader.readLine().trim().toLowerCase();
                if (!action.equals("register") && !action.equals("login") && !action.equals("admin")) {
                    bufferedwriter.write("Invalid input! Please enter 'register' or 'login' or 'admin'.");
                    bufferedwriter.newLine();
                    bufferedwriter.flush();
                    continue;
                }

                bufferedwriter.write("Enter your username:");
                bufferedwriter.newLine();
                bufferedwriter.flush();
                String username = bufferedreader.readLine().trim();
                bufferedwriter.write("Enter your password:");
                bufferedwriter.newLine();
                bufferedwriter.flush();
                String password = bufferedreader.readLine().trim();

                if (action.equals("register")) {
                    bufferedwriter.write("Enter type (Customer/Driver):");
                    bufferedwriter.newLine();
                    bufferedwriter.flush();
                    String type = bufferedreader.readLine().trim();
                    String response = UserService.registerUser(username, password, type);
                    bufferedwriter.write(response);
                    bufferedwriter.newLine();
                    bufferedwriter.flush();
                } else if (action.equals("admin")) {
                    this.user = UserService.loginAdmin(username, password);
                    if (user == null) {
                        bufferedwriter.write("Invalid credentials!");
                        bufferedwriter.newLine();
                        bufferedwriter.flush();
                        continue;
                    }
                    bufferedwriter.write("Admin " + user.name + " logged in successfully!");
                    bufferedwriter.newLine();
                    bufferedwriter.flush();
                    handleAdmin();
                } else {
                    this.user = UserService.loginUser(username, password);
                    if (user == null) {
                        bufferedwriter.write("Invalid credentials!");
                        bufferedwriter.newLine();
                        bufferedwriter.flush();
                        continue;
                    }
                    if (user instanceof Customer) {
                        bufferedwriter.write("Customer " + user.name + " logged in successfully!");
                        bufferedwriter.newLine();
                        bufferedwriter.flush();
                        synchronized (customers) {
                            customers.add(this);
                        }
                    } else if (user instanceof Driver) {
                        bufferedwriter.write("Driver " + user.name + " logged in successfully!");
                        bufferedwriter.newLine();
                        bufferedwriter.flush();
                        synchronized (drivers) {
                            drivers.add(this);
                            //broadcastRequestedRidestoDrivers();
                            broadcastRequestedRidestospecificDriver(user.name);
                        }
                    }
                }

                if (user instanceof Customer) {
                    handleCustomer();
                } else if (user instanceof Driver) {
                    handleDriver();
                }

            } catch (IOException e) {
                System.out.println(user.name + " has disconnected");
                return;

            }
        }
    }

    public void notifycustomerwithoffer(int rideId) throws IOException {
        Ride ride = UserService.getRideById(rideId);
        if (ride == null) return;

        String c_name = ride.customer.name;
        StringBuilder rideInfo = new StringBuilder("Offered Rides:\n");

        for (Driver driver : ride.RequestedDrivers) {
            if (driver.is0nline) {
                double price = ride.getDriverOffer(driver.name);
                rideInfo.append("Driver: ").append(driver.name)
                        .append(" | Price: $").append(price)
                        .append(" | Pickup: ").append(ride.pickupLocation)
                        .append(" | Destination: ").append(ride.destination)
                        .append(" | Rating: ").append(driver.Rating)
                        .append("\n");
            }
        }

        boolean customerFound = false;
        for (ClientHandler customer : customers) {
            if (customer.user.name.equals(c_name)) {
                customer.sendMessage(rideInfo.toString());
                customerFound = true;
                break;
            }
        }

        if (!customerFound) {
            System.out.println("Customer " + c_name + " not found (probably disconnected).");
            for(Driver driver:ride.RequestedDrivers)
            {
                if(driver.is0nline)
                {
                    for(ClientHandler ch:drivers)
                    {
                        if(ch.user.name.equalsIgnoreCase(driver.name))
                        {
                            driver.isAvailable=true;
                           ch.sendMessage("The ride"+rideId+" is no longer available pick another ride");
                           broadcastRequestedRidestospecificDriver(driver.name);

                        }
                    }
                }
            }
        }
    }


    public void notifycustomerwithRideUpdate(String cname, String Status, Ride ride) throws IOException {
        for (ClientHandler customer : customers) {
            if (customer.user.name.equals(cname)) {
                customer.sendMessage("Ride status updated to: " + Status);
                if ("Started".equalsIgnoreCase(Status)) {
                    ride.status = "Ongoing";
                }
                if ("Completed".equalsIgnoreCase(Status)) {
                    ((Customer) customer.user).isAvailable = true;
                    ride.CurrentDriver.isAvailable = true;
                    ride.CurrentCustomer.isAvailable = true;
                    customer.sendMessage("Please pay " + ride.price + ", Press 3 to rate your ride!");
                    //broadcastRequestedRidestoDrivers();
                    broadcastRequestedRidestospecificDriver(ride.CurrentDriver.name);

                }
            }

        }
    }


    public void notifydriverwithRateUpdate(String dname, double rating) throws IOException {
        boolean found = false; // flag to track if driver was found

        for (ClientHandler driver : drivers) {
            if (driver.user.name.equals(dname)) {
                driver.sendMessage("Your Rating has been updated to: " + rating);
                found = true; // set flag if found
                break; // stop loop if driver found (optional if names are unique)
            }
        }

        if (!found) {
            System.out.println("Driver "+dname+ " disconnected, could not deliver rating update.");
        }
    }


    public void notifydriverwithacceptedoffer(String dname, String cname, Ride ride) throws IOException {
        for (ClientHandler driver : drivers) {
            if (driver.user.name.equalsIgnoreCase(dname)) {
                driver.sendMessage("Ride accepted successfully  ! Customer: " + cname);
                ((Driver) driver.user).isAvailable = false;
                ((Driver) driver.user).inRide = true;

            } else if (ride.RequestedDrivers.contains((Driver) driver.user)) {
                driver.sendMessage(cname + " has declined your offer");
                ((Driver) driver.user).isAvailable = true;
                broadcastRequestedRidestoDrivers();
            }
        }
        //broadcastRequestedRidestoDrivers();
    }

    public void closeCustomerConnection(String cname) {
        ClientHandler toRemove = null;
        for (ClientHandler customer : customers) {
            if (customer.user.name.equals(cname)) {
                toRemove = customer;
                break;
            }
        }
        if (toRemove != null) {
            customers.remove(toRemove);
            toRemove.sendMessage("Disconnected from server.");
            toRemove.closeConnection();
        }
    }

    public void closeDriverConnection(String dname) {
        ClientHandler toRemove = null;
        for (ClientHandler driver : drivers) {
            if (driver.user.name.equals(dname)) {
                toRemove = driver;
                break;
            }
        }
        if (toRemove != null) {
            drivers.remove(toRemove);
            toRemove.sendMessage("Disconnected from server.");
            toRemove.closeConnection();
        }
    }

    /*public void broadcastRequestedRidestoDrivers() throws IOException {
        List<Ride> availableRides = UserService.getRequestedRides();
        List<Integer> rideIds = new ArrayList<>();


        StringBuilder rideInfo = new StringBuilder("Available Rides:\n");
        for (Ride ride : availableRides) {
            if (ride.status.equalsIgnoreCase("Pending") && ride.CurrentDriver == null) {

                rideInfo.append("Ride ID: ").append(ride.rideId)
                        .append(" | Pickup: ").append(ride.pickupLocation)
                        .append(" | Destination: ").append(ride.destination)
                        .append("\n");
                rideIds.add(ride.rideId);
            }
        }

        synchronized (drivers) {
            boolean assigned = false;
            for (ClientHandler driver : drivers) {

                if (driver.user instanceof Driver && ((Driver) driver.user).isAvailable && ((Driver) driver.user).Rating >= 3.5) {
                    assigned = true;
                    ((Driver) driver.user).recievedtheride = true;
                    ((Driver) driver.user).receivedRequestRides.addAll(rideIds);
                    double rating=((Driver) driver.user).Rating;
                    driver.sendMessage(String.valueOf(rating));
                    driver.sendMessage(rideInfo.toString());
                } else if (assigned == false && driver.user instanceof Driver && ((Driver) driver.user).isAvailable && ((Driver) driver.user).Rating < 3.5) {
                    ((Driver) driver.user).recievedtheride = true;
                    ((Driver) driver.user).receivedRequestRides.addAll(rideIds);
                    driver.sendMessage(rideInfo.toString());
                }
            }
        }
    }*/
    public void broadcastRequestedRidestoDrivers() throws IOException {
        List<Ride> availableRides = UserService.getRequestedRides();
        List<Integer> rideIds = new ArrayList<>();

        StringBuilder rideInfo = new StringBuilder("Available Rides:\n");
        for (Ride ride : availableRides) {
            if (ride.status.equalsIgnoreCase("Pending") && ride.CurrentDriver == null&&ride.customer.is0nline) {
                rideInfo.append("Ride ID: ").append(ride.rideId)
                        .append(" | Pickup: ").append(ride.pickupLocation)
                        .append(" | Destination: ").append(ride.destination)
                        .append("\n");
                rideIds.add(ride.rideId);
            }
        }

        synchronized (drivers) {
            // Step 1: Send to high-rated drivers only
            for (ClientHandler driver : drivers) {
                if (driver.user instanceof Driver) {
                    Driver d = (Driver) driver.user;
                    if (d.isAvailable && d.Rating >= 3.5) {
                        d.recievedtheride = true;
                        d.receivedRequestRides.addAll(rideIds);
                        driver.sendMessage("You are a top-rated driver. New ride request:\n" + rideInfo.toString());
                    }
                }
            }
        }

        new Thread(() -> {
            try {
                Thread.sleep(30000);

                // Step 3: Recheck for unassigned rides
                List<Ride> stillUnassigned = UserService.getRequestedRides(); // re-check rides
                List<Integer> lowRatedRideIds = new ArrayList<>();
                StringBuilder lowRatedRideInfo = new StringBuilder("Available Rides:\n");

                for (Ride ride : stillUnassigned) {
                    if (ride.status.equalsIgnoreCase("Pending") && ride.CurrentDriver == null&&ride.customer.is0nline) {
                        lowRatedRideInfo.append("Ride ID: ").append(ride.rideId)
                                .append(" | Pickup: ").append(ride.pickupLocation)
                                .append(" | Destination: ").append(ride.destination)
                                .append("\n");
                        lowRatedRideIds.add(ride.rideId);
                    }
                }

                // Only send to low-rated drivers if there are rides to show
                if (!lowRatedRideIds.isEmpty()) {
                    synchronized (drivers) {
                        for (ClientHandler driver : drivers) {
                            if (driver.user instanceof Driver) {
                                Driver d = (Driver) driver.user;
                                if (d.isAvailable && d.Rating < 3.5) {
                                    d.recievedtheride = true;
                                    d.receivedRequestRides.addAll(lowRatedRideIds);
                                    driver.sendMessage("You have a ride request:\n" + lowRatedRideInfo.toString());
                                }
                            }
                        }
                    }
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }


    /*public void broadcastRequestedRidestospecificDriver(String drivername) throws IOException {
        List<Ride> availableRides = UserService.getRequestedRides();
        List<Integer> rideIds = new ArrayList<>();


        StringBuilder rideInfo = new StringBuilder("Available Rides:\n");
        for (Ride ride : availableRides) {
            if (ride.status.equalsIgnoreCase("Pending") && ride.CurrentDriver == null) {

                rideInfo.append("Ride ID: ").append(ride.rideId)
                        .append(" | Pickup: ").append(ride.pickupLocation)
                        .append(" | Destination: ").append(ride.destination)
                        .append("\n");
                rideIds.add(ride.rideId);
            }
        }

        synchronized (drivers) {
            boolean assigned = false;
            for (ClientHandler driver : drivers) {

                if (driver.user instanceof Driver && ((Driver) driver.user).isAvailable && ((Driver) driver.user).Rating >= 3.5 && ((Driver) driver.user).name.equalsIgnoreCase(drivername)) {
                    assigned = true;
                    ((Driver) driver.user).recievedtheride = true;
                    ((Driver) driver.user).receivedRequestRides.addAll(rideIds);
                    driver.sendMessage(rideInfo.toString());
                } else if (assigned == false && driver.user instanceof Driver && ((Driver) driver.user).isAvailable && ((Driver) driver.user).Rating < 3.5 && ((Driver) driver.user).name.equalsIgnoreCase(drivername)) {
                    ((Driver) driver.user).recievedtheride = true;
                    ((Driver) driver.user).receivedRequestRides.addAll(rideIds);
                    driver.sendMessage(rideInfo.toString());
                }
            }
        }
    }*/
    public void broadcastRequestedRidestospecificDriver(String drivername) throws IOException {
        List<Ride> availableRides = UserService.getRequestedRides();
        List<Integer> rideIds = new ArrayList<>();

        StringBuilder rideInfo = new StringBuilder("Available Rides:\n");

        long currentTime = System.currentTimeMillis();
        int sentCount = 0;

        synchronized (drivers) {
            for (ClientHandler driver : drivers) {
                if (driver.user instanceof Driver) {
                    Driver d = (Driver) driver.user;

                    if (!d.name.equalsIgnoreCase(drivername) || !d.isAvailable) {
                        continue; // Skip if name doesn't match or not available
                    }

                    for (Ride ride : availableRides) {
                        // Ensure ride is pending and not assigned
                        if (ride.status.equalsIgnoreCase("Pending") && ride.CurrentDriver == null&&ride.customer.is0nline) {
                            // Handle high-rated driver (>= 3.5)
                            if (d.Rating >= 3.5) {
                                rideInfo.append("Ride ID: ").append(ride.rideId)
                                        .append(" | Pickup: ").append(ride.pickupLocation)
                                        .append(" | Destination: ").append(ride.destination)
                                        .append("\n");
                                rideIds.add(ride.rideId);
                                sentCount++;
                            }
                            // Handle low-rated driver (< 3.5) but only if ride waited >10 sec
                            else if ((currentTime - ride.requestedTime.getTime()) >= 10000) {
                                rideInfo.append("Ride ID: ").append(ride.rideId)
                                        .append(" | Pickup: ").append(ride.pickupLocation)
                                        .append(" | Destination: ").append(ride.destination)
                                        .append("\n");
                                rideIds.add(ride.rideId);
                                sentCount++;
                            }
                        }
                    }

                    if (sentCount > 0) {
                        d.recievedtheride = true;
                        d.receivedRequestRides.addAll(rideIds);
                        driver.sendMessage(rideInfo.toString());
                    }
                }
            }
        }
    }


    public void sendMessage(String message) {
        try {
            bufferedwriter.write(message);
            bufferedwriter.newLine();
            bufferedwriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void handleCustomer() throws IOException {
        sendMessage("1. Request a ride");
        sendMessage("2. Accept Offer");
        sendMessage("3. View current ride status");
        sendMessage("4. Disconnect");

        while (true) {
            String command = bufferedreader.readLine();
            if ("1".equals(command)) {
                boolean hasAvailableDrivers = false;
                synchronized (drivers) {
                    for (ClientHandler driver : drivers) {
                        if (driver.user instanceof Driver && ((Driver) driver.user).isAvailable) {
                            hasAvailableDrivers = true;
                            break;
                        }
                    }
                }
                if (!((Customer) user).isAvailable) {
                    sendMessage("You have already requested a ride.");
                    continue;
                }


                if (!hasAvailableDrivers) {
                    sendMessage("No available drivers at the moment. Please try again later.");
                    continue;
                }
                sendMessage("Enter pickup location:");
                String pickup;
                while (true) {
                    pickup = bufferedreader.readLine().trim();
                    if (pickup.isEmpty()) {
                        sendMessage("Pickup location cannot be empty. Please enter again:");
                    } else {
                        break;
                    }
                }

                sendMessage("Enter destination:");
                String destination;
                while (true) {
                    destination = bufferedreader.readLine().trim();
                    if (destination.isEmpty()) {
                        sendMessage("Destination cannot be empty. Please enter again:");
                    } else {
                        break;
                    }
                }
                String rideResponse = UserService.requestRide((Customer) user, pickup, destination);
                sendMessage(rideResponse);
                broadcastRequestedRidestoDrivers();
            } else if ("2".equals(command)) {
                sendMessage("Enter Driver Name to accept:");
                String D_name = bufferedreader.readLine();
                Driver d=UserService.getDriverByName(D_name);
                if (d == null) {
                    sendMessage("invalid input.");
                    continue;
                }
                int rideid=UserService.getRideIdByCustomerName(user.name);
                if (rideid == -1) {
                    sendMessage("No ride found for you.");
                    continue;
                }
                if(!d.is0nline)
                {
                    sendMessage(" Sorry The driver is no longer available. Please choose another offer");
                    ((Customer) user).isAvailable=true;
                    notifycustomerwithoffer(rideid);
                    continue;

                }

                Ride acceptResponse = UserService.AcceptRide(D_name, (Customer) user);
                if (acceptResponse == null) {
                    sendMessage("Invalid input");
                    continue;
                } else {

                    sendMessage(" Ride accepted successfully! Driver: " + acceptResponse.driver.name + " | Price: $" + acceptResponse.price);
                }

                //ride
                notifydriverwithacceptedoffer(D_name, user.name, acceptResponse);
                //broadcastRequestedRidestoDrivers(); // update list after accepting
            } else if ("3".equals(command)) {
                Ride ride = UserService.getCustomerCurrentRide((Customer) user);
                if (ride == null) {
                    sendMessage("No rides to display.");
                    continue;
                }
                sendMessage("Latest Ride Status: " + ride.status);
                if ("Completed".equalsIgnoreCase(ride.status) && !ride.rated) {
                    try {
                        // Rate Driver cleanliness from 1 to 5
                        sendMessage("Rate Driver cleanliness from 1 to 5");
                        double cleanliness = getValidRatingInput();

                        // Rate Driver drivingSkills from 1 to 5
                        sendMessage("Rate Driver drivingSkills from 1 to 5");
                        double drivingSkills = getValidRatingInput();


                        sendMessage("Rate Driver navigationSkills from 1 to 5");
                        double navigationSkills = getValidRatingInput();


                        UserService.rateDriver(ride.CurrentDriver.name, cleanliness, drivingSkills, navigationSkills);
                        System.out.println("Driver " + ride.CurrentDriver.name + " rated successfully with Rating: " + ride.CurrentDriver.Rating);

                        // Mark the ride as rated
                        ride.rated = true;

                        // Notify the driver with the rating update
                        notifydriverwithRateUpdate(ride.CurrentDriver.name, ride.CurrentDriver.Rating);

                    } catch (NumberFormatException e) {
                        sendMessage("Invalid input detected. Please enter numeric values between 1 and 5.");

                    }
                }
            }
            else if ("4".equals(command)) {
                //String cname=user.name;

                Ride ride = UserService.getCustomerCurrentRide((Customer) user);
                if (ride != null && (ride.status.equalsIgnoreCase("Ongoing") || ride.status.equalsIgnoreCase("started")||ride.status.toLowerCase().contains("away"))) {
                    sendMessage("You are in a ride. Cannot disconnect");
                    continue;
                }
                user.is0nline=false;
                ((Customer) user).isAvailable=true;
                closeCustomerConnection(user.name);
                if(ride.status.equalsIgnoreCase("Pending"))
                {
                    for(Driver driver:ride.RequestedDrivers)
                    {
                        if(driver.is0nline)
                        {
                            for(ClientHandler ch:drivers)
                            {
                                if(ch.user.name.equalsIgnoreCase(driver.name))
                                {
                                    driver.isAvailable=true;
                                    ch.sendMessage("The ride "+ride.rideId+" is no longer available pick another ride");
                                    broadcastRequestedRidestospecificDriver(driver.name);

                                }
                            }
                        }
                    }
                }
                return;  // Ensure the loop exits

            } else {
                sendMessage("Invalid choice. Try again.");

            }
        }
    }
    private double getValidRatingInput() throws IOException {
        while (true) {
            String input = bufferedreader.readLine().trim();

            // Check if input is empty
            if (input.isEmpty()) {
                sendMessage("Input cannot be empty. Please enter a rating between 1 and 5.");
                continue;
            }

            try {
                double rating = Double.parseDouble(input);

                // Check if the rating is within the valid range
                if (rating >= 1 && rating <= 5) {
                    return rating;
                } else {
                    sendMessage("Invalid rating! Please enter a number between 1 and 5.");

                }
            } catch (NumberFormatException e) {
                sendMessage("Invalid input! Please enter a numeric value between 1 and 5.");

            }
        }
    }
    private void handleDriver() throws IOException {
        sendMessage("1. Find available rides");
        sendMessage("2. Offer fare for a ride");
        sendMessage("3. Update ride status");
        sendMessage("4. View Rating");
        sendMessage("5. Disconnect");

        while (true) {

            String command = bufferedreader.readLine();
            if("1".equals(command))
            {
                if (!((Driver) user).isAvailable) {
                    sendMessage("You have already accepted a ride.");
                    continue;
                }

                broadcastRequestedRidestospecificDriver((user).name);

            }
            else if ("2".equals(command)) {
                if (!((Driver) user).isAvailable) {
                    sendMessage("You have already accepted a ride.");
                    continue;
                }
                if (!((Driver) user).recievedtheride) {
                    sendMessage("You are not authorized to accept a ride .");
                    continue;
                }

                sendMessage("Enter Ride ID to offer fare:");
                int rideId = Integer.parseInt(bufferedreader.readLine());
                if (!((Driver) user).receivedRequestRides.contains(rideId)) {
                    sendMessage("You cant accept this ride .");
                    continue;
                }
                sendMessage("Enter fare amount:");
                double fare = Double.parseDouble(bufferedreader.readLine());
                Customer customer = UserService.getCustomerFromRideId(rideId);
                if (!customer.is0nline)
                {
                    sendMessage("Sorry The ride request is no longer valid, please pick another ride.");
                    broadcastRequestedRidestospecificDriver(user.name);
                    continue;

                }

                String offerResponse = UserService.offerFare((Driver) user, rideId, fare);
                //c_name = UserService.getCustomernameFromRideId(rideId);
                sendMessage(offerResponse);
                if (offerResponse.contains("Fare offer submitted")) {
                    notifycustomerwithoffer(rideId);

                }

            } else if ("3".equals(command)) {
                if (((Driver) user).isAvailable) {
                    sendMessage("you are not in a ride");
                    continue;
                }
                sendMessage("Enter Ride status (Started | Completed | X minutes away):");
                String status = bufferedreader.readLine();
                Ride updateResponse = UserService.updateRideStatus((Driver) user, status);
                if (status.equalsIgnoreCase("completed")) {
                    ((Driver) user).isAvailable = true;
                }
                if (updateResponse == null) {
                    sendMessage("No rides to update");
                    continue;
                }
                String currentridername = updateResponse.CurrentCustomer.name;
                notifycustomerwithRideUpdate(currentridername, status, updateResponse);


            } else if ("4".equals(command)) {
                double rating=((Driver)user).Rating;
                sendMessage("Your Rating is "+rating);



            } else if ("5".equals(command)) {
                String dname = user.name;
                Ride ride = UserService.getDriverCurrentRide((Driver) user);
                if (ride != null && (ride.status.equalsIgnoreCase("Ongoing") || ride.status.equalsIgnoreCase("Started")||ride.status.toLowerCase().contains("away"))) {
                    sendMessage("You are in a ride. Cannot disconnect");
                    continue;
                }
                //sendMessage("You have been disconnected.");
                user.is0nline=false;
                ((Driver) user).isAvailable=true;
                closeDriverConnection(dname);
                return;
            } else {
                sendMessage("Invalid choice. Try again.");

            }
        }
    }

    public void handleAdmin() throws IOException {
        sendMessage("1. View Statistics");
        sendMessage("2. Save Data");
        while (true) {
            String command = bufferedreader.readLine();
            if ("1".equals(command)) {
                String stat = UserService.getAdminStatistics();
                sendMessage(stat);

            } else if ("2".equals(command)) {
                String save = UserService.saveData();
                sendMessage(save);
            }

        }


    }

    public void closeConnection() {
        try {
            if (bufferedreader != null) {
                bufferedreader.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            if (bufferedwriter != null) {
                bufferedwriter.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
