package Features;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import Entities.*;


public class UserService {
    private static List<User> users = new ArrayList<>();
    private static List<Ride> rides = new ArrayList<>();
    public static Admin admin=new Admin("admin155", "admin", "admin123");
    private static final String DATA_FILE = "data.txt";
     static {
        loadData(); // Load data at startup
    }

    // Admin calls this to save data manually
    public static synchronized String saveData() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE))) {
            for (User user : users) {
                if (user instanceof Driver) {
                    Driver driver = (Driver) user;
                    writer.println("Driver," + driver.id + "," + driver.name + "," + driver.password + "," +
                                   driver.isAvailable + "," + driver.Rating + "," + driver.ratingCount);
                } else if (user instanceof Customer) {
                    Customer customer = (Customer) user;
                    writer.println("Customer," + customer.id + "," + customer.name + "," + customer.password + "," + customer.isAvailable);
                }
            }
            for (Ride ride : rides) {
                writer.println("Ride," + ride.rideId + "," + ride.customer.id + "," + ride.pickupLocation + "," + ride.destination + "," + ride.status);
            }
            return "Data saved successfully!";
        } catch (IOException e) {
            return "Error saving data: " + e.getMessage();
        }
    }
    
    // Load data from file at startup
    private static synchronized void loadData() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return;
    
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                
                // Check if the parts array has enough elements
                if (parts.length < 2) continue;  // Skip invalid lines
    
                if (parts[0].equals("Customer") && parts.length >= 5) {
                    // Ensure proper parsing of isAvailable
                    boolean isAvailable = Boolean.parseBoolean(parts[4]);
                    users.add(new Customer(parts[1], parts[2], parts[3], isAvailable));
    
                } else if (parts[0].equals("Driver") && parts.length >= 7) {
                    // Ensure proper parsing of boolean and numeric values
                    boolean isAvailable = Boolean.parseBoolean(parts[4]);
                    double rating = Double.parseDouble(parts[5]);
                    int ratingCount = Integer.parseInt(parts[6]);
    
                    users.add(new Driver(parts[1], parts[2], parts[3], isAvailable, rating, ratingCount));
    
                } else if (parts[0].equals("Ride") && parts.length >= 6) {
                    Customer customer = (Customer) findUserById(parts[2]);

                    if (customer != null) {
                        Ride r=new Ride(Integer.parseInt(parts[1]), customer, parts[3], parts[4], parts[5]);
                        r.status=parts[5];
                        rides.add(r);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }
    
    private static User findUserById(String id) {
        for (User user : users) {
            if (user.id.equals(id)) return user;
        }
        return null;
    }
  
   
    // Register a new user
    public static synchronized String registerUser(String username, String password, String type) {
        // Check if username already exists
        for (User user : users) {
            if (user.name.equalsIgnoreCase(username)) {
                return "Username already exists!";
            }
        }

        // Validate type
        if (!type.equalsIgnoreCase("Customer") && !type.equalsIgnoreCase("Driver")) {
            return "Invalid user type! Must be 'Customer' or 'Driver'.";
        }

        // Generate unique user ID
        String userId = UUID.randomUUID().toString();

        // Create user object
        User newUser;
        if (type.equalsIgnoreCase("Customer")) {
            newUser = new Customer(userId, username, password, true);
        } else {
            newUser = new Driver(userId, username, password, true, 5.0, 0);
        }

        // Add to user list
        users.add(newUser);
        return "Registration successful! Your ID: " + userId;
    }

    //  Login user
    public static synchronized User loginUser(String username, String password) {
        for (User user : users) {
            if (user.name.equalsIgnoreCase(username) && user.password.equals(password)) {
                user.is0nline=true;
                return user; // Return user if credentials match
            }
        }
        return null; // Invalid credentials
    }
//customer request ride
     public static synchronized String requestRide(Customer customer, String pickup, String destination) {

        Ride newRide = new Ride(rides.size() + 1, customer, pickup, destination, "Pending");
        newRide.CurrentCustomer=customer;
        customer.isAvailable = false;
        rides.add(newRide);
        return "Ride request submitted successfully ,waiting for drivers offers!";
    }
//driver get requested ride
public static synchronized List<Ride> getRequestedRides() {
    List<Ride> availableRides = new ArrayList<>();
    for (Ride ride : rides) {
        if (ride.status.equals("Pending") && ride.CurrentDriver == null) {
            availableRides.add(ride);
        }
    }
    return availableRides;
}

    public static synchronized String offerFare(Driver driver, int rideId, double price) {
        for (Ride ride : rides) {
            if (ride.rideId == rideId && ride.status.equalsIgnoreCase("Pending") && ride.CurrentDriver == null && driver.isAvailable) {
                ride.assignDriver(driver, price); // Store fare per driver
                ride.RequestedDrivers.add(driver);
                driver.isAvailable = false;
                return "Fare offer submitted for Ride ID: " + ride.rideId;
            }
        }
        return "Cannot offer this ride";
    }

    public static synchronized Ride AcceptRide(String d_name, Customer C) {
        for (Ride ride : rides) {
            if (ride.status.equals("Pending")&&ride.customer.equals(C)) {
                for (Driver driver : ride.RequestedDrivers) {
                    if (driver.name.equalsIgnoreCase(d_name)) {
                        ride.CurrentDriver = driver;
                        ride.CurrentCustomer = C;
                        ride.status = "Ongoing";//momken nekhaleha on the way bardo 
                        driver.isAvailable = false;
                        double acceptedPrice = ride.getDriverOffer(driver.name);
                        ride.price = acceptedPrice;
                        ride.driver=driver;
                        return ride;
                    } else {
                        //System.out.println(driver.name+"is now available");
                        driver.isAvailable = true;
                        
                    }
                }
            }
        }
        return null;
    }
    public static synchronized Ride updateRideStatus(Driver d, String Status) {
        for (Ride ride : rides) {
            if (ride.CurrentDriver != null && ride.CurrentDriver.name.equals(d.name)&&(!ride.status.equalsIgnoreCase("completed"))) {
                ride.status = Status;
                return ride;  
            }
        }
        return null;  
    }    
    public static synchronized Ride getCustomerCurrentRide(Customer c) {
        Deque<Ride> deque = new ArrayDeque<>();
        for (Ride ride : rides) {
            if (ride.CurrentCustomer != null && ride.CurrentCustomer.name.equalsIgnoreCase(c.name) && ride.rated == false ) {
                    deque.addFirst(ride);
            }
        }
        if (!deque.isEmpty()) {
            return deque.pollFirst();
        }
        return null;  //elcustomer momken yeb2a 3ando rides kteera f bngeeb akher wa7da mawgoda 
    }
    public static synchronized Ride getDriverCurrentRide(Driver d) {
        Deque<Ride> deque = new ArrayDeque<>();
        for (Ride ride : rides) {
            if (ride.CurrentCustomer != null&& ride.CurrentDriver != null  && ride.CurrentDriver.name.equalsIgnoreCase(d.name)) {
                deque.addFirst(ride);
            }
        }
        if (!deque.isEmpty()) {
            return deque.pollFirst();
        }
        return null;  
    }



public static synchronized Customer getCustomerFromRideId(int rideId) {
    for (Ride ride : rides) {
        if (ride.rideId == rideId) {
            return ride.customer;
        }
    }
    return null;
}
public static synchronized List<User> getAllUsers() {
   return new ArrayList<>(users);
}
    //N7 Disconnect
    public static synchronized boolean canDisconnect(String userId) {
        for (Ride ride : rides) {
            if (ride.status.equals("Ongoing") &&
                    (ride.customer.id.equals(userId) || (ride.driver != null && ride.driver.id.equals(userId)))) {
                return false; // In an ongoing ride
            }
        }
        return true;
    }
    public static synchronized String rateDriver(String drivername, double cleanliness, double drivingSkills, double navigationSkills) {
        for (User user : users) {
            if (user instanceof Driver && user.name.equals(drivername)) {
                Driver driver = (Driver) user;
    
                // Validate ratings (1-5)
                if (cleanliness < 1 || cleanliness > 5 || drivingSkills < 1 || drivingSkills > 5 || navigationSkills < 1 || navigationSkills > 5) {
                    return "Invalid rating! Each category must be between 1 and 5.";
                }
    
                // Calculate average rating
                double newrating = (cleanliness + drivingSkills + navigationSkills) / 3.0;
                driver.Rating=(driver.Rating*driver.ratingCount+newrating)/(driver.ratingCount+1);
                driver.ratingCount++;
                //driver.isAvailable=true;//because the ride is completed
                return "Driver " + driver.name + " has been rated successfully!";
    
            }
        }
        return "Driver not found!";
        
    }

    public static synchronized Ride getRideById(int rideId) {
    for (Ride ride : rides) {
        if (ride.rideId == rideId) {
            return ride; // Return the ride if found
        }
    }
    return null; // Return null if the ride is not found
}
public static synchronized User loginAdmin(String username, String password) {
    if (admin.name.equalsIgnoreCase(username) && admin.password.equals(password)) {
        return admin; 
    }
    return null; 
}

    //N8 Statistics
    public static synchronized String getAdminStatistics() {

        int totalRides = rides.size();
        int completed = 0, ongoing = 0, pending = 0, accepted = 0;
        int totalDrivers = 0, totalCustomers = 0;
        StringBuilder rideDetails = new StringBuilder();
    
        // Count ride statuses
        for (Ride ride : rides) {
            switch (ride.status) {
                case "Completed": completed++; break;
                case "Ongoing": ongoing++; break;
                case "Pending": pending++; break;
                case "Accepted": accepted++; break;
            }
            
            // Append ride details
            rideDetails.append("Ride ID: ").append(ride.rideId)
                       .append(" | Pickup: ").append(ride.pickupLocation)
                       .append(" | Destination: ").append(ride.destination)
                       .append(" | Status: ").append(ride.status)
                       .append(" | Customer: ").append(ride.customer != null ? ride.customer.name : "N/A")
                       .append(" | Driver: ").append(ride.CurrentDriver != null ? ride.CurrentDriver.name : "N/A").append(" | Price: ").append(ride.price)
                       .append("\n");
        }
    
        // Count customers and drivers
        for (User user : users) {
            if (user instanceof Driver) totalDrivers++;
            else if (user instanceof Customer) totalCustomers++;
        }
    
        // Format the statistics output
        return "===== Admin Ride Statistics =====\n" +
               "Total Rides: " + totalRides + "\n" +
               "Pending: " + pending + " | Accepted: " + accepted + " | Ongoing: " + ongoing + " | Completed: " + completed + "\n" +
               "Total Customers: " + totalCustomers + "\n" +
               "Total Drivers: " + totalDrivers + "\n" +
               "\n===== Ride Details =====\n" +
               rideDetails.toString();
    }

    public static synchronized String getRideDuration(Ride ride) {
        if (ride.status.equals("Ongoing") && ride.requestedTime != null) {
            long duration = new Date().getTime() - ride.requestedTime.getTime();
            long seconds = (duration / 1000) % 60;
            long minutes = (duration / (1000 * 60)) % 60;
            long hours = (duration / (1000 * 60 * 60)) % 24;

            return String.format("Ride Duration: %02d:%02d:%02d", hours, minutes, seconds);
        }
        return "Ride is not ongoing.";
    }
    public static synchronized Driver getDriverByName(String driverName) {
        for (User user : users) {
            if (user instanceof Driver && user.name.equalsIgnoreCase(driverName)) {
                return (Driver) user;
            }
        }
        return null;
    }
    public static synchronized int getRideIdByCustomerName(String customerName) {
        for (Ride ride :rides) {
            if (ride.customer.name.equals(customerName)&&ride.status.equalsIgnoreCase("Pending")) {
                return ride.rideId; // Assuming ride has a unique id field
            }
        }
        return -1; // or throw an exception if not found
    }





}

